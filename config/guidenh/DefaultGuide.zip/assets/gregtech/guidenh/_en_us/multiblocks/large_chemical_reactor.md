---
item_ids:
  - gregtech:gt.blockmachines:1169
bindings:
  - {type: "betterquesting", id: "AAAAAAAAAAAAAAAAAAAMOQ=="}
navigation:
  title: Large Chemical Reactor
  parent: ./multiblocks_index.md
  icon: gregtech:gt.blockmachines:1169
  position: -3001
---
# Large Chemical Reactor
