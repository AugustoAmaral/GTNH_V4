---
item_ids:
  - gregtech:gt.blockmachines:15563
bindings:
  - {type: "betterquesting", id: "IlCOpa8bR9WbOjSOPxZIlA=="}
navigation:
  title: Electric Implosion Compressor
  parent: ./multiblocks_index.md
  icon: gregtech:gt.blockmachines:15563
  position: -9001
---
# Electric Implosion Compressor
