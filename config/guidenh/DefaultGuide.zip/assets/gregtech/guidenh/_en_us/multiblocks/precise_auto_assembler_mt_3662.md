---
item_ids:
  - gregtech:gt.blockmachines:32018
  - GoodGenerator:impreciseUnitCasing
  - GoodGenerator:preciseUnitCasing
  - GoodGenerator:preciseUnitCasing:1
  - GoodGenerator:preciseUnitCasing:2
  - GoodGenerator:preciseUnitCasing:3
bindings:
  - {type: "betterquesting", id: "AAAAAAAAAAAAAAAAAAAMEg=="}
  - {type: "betterquesting", id: "AAAAAAAAAAAAAAAAAAAKcA=="}
navigation:
  title: Precise Auto-Assembler MT-3662
  parent: ./multiblocks_index.md
  icon: gregtech:gt.blockmachines:32018
  position: -5001
---
# Precise Auto-Assembler MT-3662
