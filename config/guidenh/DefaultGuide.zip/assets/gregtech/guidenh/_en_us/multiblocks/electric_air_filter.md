---
item_ids:
  - gregtech:gt.blockmachines:12020
  - gregtech:gt.blockmachines:12021
  - gregtech:gt.blockmachines:12022
bindings:
  - {type: "betterquesting", id: "AAAAAAAAAAAAAAAAAAALpQ=="}
navigation:
  title: Electric Air Filter
  parent: ./multiblocks_index.md
  icon: gregtech:gt.blockmachines:12020
  position: -1001
---
# Electric Air Filter
